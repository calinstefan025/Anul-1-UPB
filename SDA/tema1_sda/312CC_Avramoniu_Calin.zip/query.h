/*AVRAMONIU Calin-Stefan - 312CC*/
#ifndef QUERY_H
#define QUERY_H

#include "queue.h"
#include "search.h"
#include "struct.h"
#include "update.h"

void show(Tren *tren, FILE *g);
void showCurrent(Tren *tren, FILE *g);
void switchq(Coada *q);

#endif