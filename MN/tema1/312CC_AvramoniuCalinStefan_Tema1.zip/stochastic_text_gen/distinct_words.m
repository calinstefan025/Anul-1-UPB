
function retval = distinct_words (tokens)
  % TODO: Find unique strings HINT: unique
  retval = unique(sort(tokens));
endfunction
