function x = oscillator(freq, fs, dur, A, D, S, R)
  x = 0;
endfunction

