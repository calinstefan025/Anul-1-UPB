function signal = low_pass(signal, fs, cutoff_freq)
  signal = 0;

  
endfunction